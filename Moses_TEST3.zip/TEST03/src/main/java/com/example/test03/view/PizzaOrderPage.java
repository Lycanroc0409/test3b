package com.example.test03.view;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import com.example.test03.model.PizzaOrder;
import com.example.test03.dao.PizzaOrderDAO;

public class PizzaOrderPage extends GridPane {

    private TextField customerNameField, mobileNumberField;
    private CheckBox xlSize, lSize, mSize, sSize;
    private Spinner<Integer> toppingCountSpinner;
    private Button addButton, updateButton, deleteButton, clearButton;
    private TableView<PizzaOrder> ordersTable;

    public PizzaOrderPage() {
        setPadding(new Insets(20));
        setVgap(15);
        setHgap(15);

        // Background color gradient: warm orange to brown
        setStyle("-fx-background-color: linear-gradient(to bottom, #eda488, #ffcc6d);");

        // UI Components with styling
        customerNameField = createStyledTextField();
        mobileNumberField = createStyledTextField();
        xlSize = createStyledCheckBox("XL");
        lSize = createStyledCheckBox("L");
        mSize = createStyledCheckBox("M");
        sSize = createStyledCheckBox("S");
        toppingCountSpinner = new Spinner<>(0, 10, 0); // Toppings count from 0 to 10
        addButton = createStyledButton("Add Order");
        updateButton = createStyledButton("Update Order");
        deleteButton = createStyledButton("Delete Order");
        clearButton = createStyledButton("Clear Form");

        ordersTable = new TableView<>();
        setupTable();

        // Layout setup
        add(new Label("Customer Name:"), 0, 0);
        add(customerNameField, 1, 0);
        add(new Label("Mobile Number:"), 0, 1);
        add(mobileNumberField, 1, 1);
        add(new Label("Pizza Size:"), 0, 2);
        add(xlSize, 1, 2);
        add(lSize, 2, 2);
        add(mSize, 3, 2);
        add(sSize, 4, 2);
        add(new Label("Number of Toppings:"), 0, 3);
        add(toppingCountSpinner, 1, 3);
        add(addButton, 0, 4);
        add(updateButton, 1, 4);
        add(deleteButton, 2, 4);
        add(clearButton, 3, 4);
        add(ordersTable, 0, 5, 5, 1);

        // Event Handlers
        addButton.setOnAction(event -> addOrder());
        updateButton.setOnAction(event -> updateOrder());
        deleteButton.setOnAction(event -> deleteOrder());
        clearButton.setOnAction(event -> clearForm());
    }

    // Helper methods for styling components

    private TextField createStyledTextField() {
        TextField textField = new TextField();
        textField.setStyle("-fx-background-color: #fff0e1; -fx-border-color: #d78c3e; -fx-border-radius: 5px; -fx-padding: 8px;");
        textField.setFont(Font.font("Arial", 14));
        return textField;
    }

    private CheckBox createStyledCheckBox(String label) {
        CheckBox checkBox = new CheckBox(label);
        checkBox.setStyle("-fx-text-fill: #f8f0e3; -fx-font-size: 14px;");
        return checkBox;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: #df5b8a; -fx-text-fill: white; -fx-border-radius: 5px; -fx-font-size: 14px; -fx-padding: 10px 20px;");
        button.setPrefWidth(150);
        button.setStyle("-fx-background-color: #df5b8a; -fx-text-fill: white; -fx-border-radius: 5px; -fx-font-size: 14px; -fx-padding: 10px 20px;");
        button.setOnMouseEntered(event -> button.setStyle("-fx-background-color: #df5b8a; -fx-text-fill: white; -fx-border-radius: 5px; -fx-font-size: 14px; -fx-padding: 10px 20px;"));
        button.setOnMouseExited(event -> button.setStyle("-fx-background-color: #df5b8a; -fx-text-fill: white; -fx-border-radius: 5px; -fx-font-size: 14px; -fx-padding: 10px 20px;"));
        return button;
    }

    private void setupTable() {
        // Set up columns for the TableView with professional look
        TableColumn<PizzaOrder, String> customerNameColumn = new TableColumn<>("Customer Name");
        customerNameColumn.setCellValueFactory(cellData -> cellData.getValue().customerNameProperty());

        TableColumn<PizzaOrder, String> mobileNumberColumn = new TableColumn<>("Mobile Number");
        mobileNumberColumn.setCellValueFactory(cellData -> cellData.getValue().mobileNumberProperty());

        TableColumn<PizzaOrder, String> pizzaSizeColumn = new TableColumn<>("Pizza Size");
        pizzaSizeColumn.setCellValueFactory(cellData -> cellData.getValue().pizzaSizeProperty());

        TableColumn<PizzaOrder, Integer> toppingsColumn = new TableColumn<>("Toppings");
        toppingsColumn.setCellValueFactory(cellData -> cellData.getValue().numToppingsProperty().asObject());

        TableColumn<PizzaOrder, Double> totalBillColumn = new TableColumn<>("Total Bill");
        totalBillColumn.setCellValueFactory(cellData -> cellData.getValue().totalBillProperty().asObject());

        ordersTable.getColumns().addAll(customerNameColumn, mobileNumberColumn, pizzaSizeColumn, toppingsColumn, totalBillColumn);

        ordersTable.setStyle("-fx-background-color: #fff0e1; -fx-border-color: #d78c3e; -fx-border-radius: 10px;");
        ordersTable.setPadding(new Insets(10));
    }

    private void addOrder() {
        String customerName = customerNameField.getText();
        String mobileNumber = mobileNumberField.getText();
        String pizzaSize = getSelectedPizzaSize();
        int numToppings = toppingCountSpinner.getValue();
        double totalBill = calculateTotalBill(pizzaSize, numToppings);

        // Create a PizzaOrder object
        PizzaOrder pizzaOrder = new PizzaOrder(customerName, mobileNumber, pizzaSize, numToppings, totalBill);

        // Use PizzaOrderDAO to save the order in the database
        PizzaOrderDAO.addOrder(pizzaOrder);

        // Update the TableView with the new order
        ordersTable.getItems().add(pizzaOrder);

        // Clear the form fields
        clearForm();
    }

    private String getSelectedPizzaSize() {
        if (xlSize.isSelected()) return "XL";
        if (lSize.isSelected()) return "L";
        if (mSize.isSelected()) return "M";
        return "S";
    }

    private double calculateTotalBill(String pizzaSize, int numToppings) {
        double sizeCost = 0;
        switch (pizzaSize) {
            case "XL": sizeCost = 15.00; break;
            case "L": sizeCost = 12.00; break;
            case "M": sizeCost = 10.00; break;
            case "S": sizeCost = 8.00; break;
        }
        double toppingCost = numToppings * 1.50;
        double total = sizeCost + toppingCost;
        return total + (total * 0.15); // Add 15% HST
    }

    private void updateOrder() {
        PizzaOrder selectedOrder = ordersTable.getSelectionModel().getSelectedItem();
        if (selectedOrder != null) {
            selectedOrder.setPizzaSize(getSelectedPizzaSize());
            selectedOrder.setNumToppings(toppingCountSpinner.getValue());
            selectedOrder.setTotalBill(calculateTotalBill(selectedOrder.getPizzaSize(), selectedOrder.getNumToppings()));
            PizzaOrderDAO.updateOrder(selectedOrder);
            ordersTable.refresh();
        }
    }

    private void deleteOrder() {
        PizzaOrder selectedOrder = ordersTable.getSelectionModel().getSelectedItem();
        if (selectedOrder != null) {
            PizzaOrderDAO.deleteOrder(selectedOrder);
            ordersTable.getItems().remove(selectedOrder);
        }
    }

    private void clearForm() {
        customerNameField.clear();
        mobileNumberField.clear();
        xlSize.setSelected(false);
        lSize.setSelected(false);
        mSize.setSelected(false);
        sSize.setSelected(false);
        toppingCountSpinner.getValueFactory().setValue(0);
    }
}
