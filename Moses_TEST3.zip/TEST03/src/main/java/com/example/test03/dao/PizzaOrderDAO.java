package com.example.test03.dao;

import com.example.test03.model.PizzaOrder;

import java.sql.*;

public class PizzaOrderDAO {

    // Add a new pizza order to the database
    public static void addOrder(PizzaOrder order) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = DatabaseManager.getConnection();
            String query = "INSERT INTO pizza_orders (customer_name, mobile_number, pizza_size, num_toppings, total_bill) VALUES (?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            statement.setString(1, order.getCustomerName());
            statement.setString(2, order.getMobileNumber());
            statement.setString(3, order.getPizzaSize());
            statement.setInt(4, order.getNumToppings());
            statement.setDouble(5, order.getTotalBill());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseManager.closeConnection(connection);
        }
    }

    // Update an existing pizza order in the database
    public static void updateOrder(PizzaOrder order) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = DatabaseManager.getConnection();
            String query = "UPDATE pizza_orders SET pizza_size = ?, num_toppings = ?, total_bill = ? WHERE customer_name = ?";
            statement = connection.prepareStatement(query);
            statement.setString(1, order.getPizzaSize());
            statement.setInt(2, order.getNumToppings());
            statement.setDouble(3, order.getTotalBill());
            statement.setString(4, order.getCustomerName());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseManager.closeConnection(connection);
        }
    }

    // Delete a pizza order from the database
    public static void deleteOrder(PizzaOrder order) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = DatabaseManager.getConnection();
            String query = "DELETE FROM pizza_orders WHERE customer_name = ?";
            statement = connection.prepareStatement(query);
            statement.setString(1, order.getCustomerName());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseManager.closeConnection(connection);
        }
    }
}
